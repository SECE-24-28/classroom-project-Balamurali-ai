// console.log(2+3);

//Variables

// b="Hello";
// c=50;
// Dont use var unles absolutely necessary as it can be used even before initialization and it can also be redeclared.
// var a = 10;
// var a = 30;
// b=10; // not allowed
// let b = "H1";
// let b = 10; // not allowed
// const c = 30.5; // cannot change the value or the datatype when declared with const.
// c = 50;
// let a = true;
// console.log(c);

// Array - is a datatype that stores multiple elements of the same datatype.
// let a = [12, 13, 15];
// console.log(a);
// const c = [10, "Hello", 30.5, true]; // can change or add or remove elements from the array even if its constant as we care not redeclaring the variable and we are not changing its datatype.
// c=[1, 2, 3] // not allowed
// c.push(15, 17, 19); // we can either insert one element or multiple elements.
// c[2] = 40; // is allowed
// console.log("Before:", c);
// c.pop();
// console.log("After:", c);
// console.log(c.length); // returns the length of the array
// c.unshift(11, 12, 13); // unshift(element) aads the element at the start.
// console.log(c);
// c.shift(); // shift() removes the element from the start
// console.log(c);

//splice(startIndex, deleteCount, item1, item2, item3, ....., itemn) // helps us to add, remove, and alter elements in our array;
// c.splice(1, 3); // delete
// console.log(c);
// c.splice(2, 0, "world"); //add
// console.log(c);
// c.splice(2, 1, 50); //replace
// console.log(c);
// c.splice(2);
// c.splice(-1, 1);
// console.log(c);

// Spread operator
// const arr1 = [5, 6, 7];
// const arr2 = [1, 2, 3, 4];
// const merge = [...arr1, ...arr2]; //[5, 6, 7, 1, 2, 3, 4]
// console.log(merge);

// const arr = [1, 2, 3, 4, 5, 6];
// console.log("Before Map Function: ", arr);

// Array Map: adds a function to each elements of the said array.
// const newArr = arr.map(num => num*5);
// console.log("After Map Function: ", newArr);

// Array Filter: creates a new array with the elements that passes the said conditions/tests.
// const newArr = arr.filter(num=>num%2===0);
// console.log("After Filter: ", newArr);
// const courses = ["MongoDB", "Express.JS", "Postgress", "React.Js", "Node.Js"];
// console.log("Courses:", courses);

// const newCourse = courses.filter(c=>c!=="Postgress");
// console.log('Updated Courses:', newCourse);

// Reduce - folds an array into a single value by calling a reducer function for each and every element.

// const arr = [1, 2, 3, 4, 5];
// const sum = arr.reduce((store, num)=> num+store);
// console.log(`Addidion of ${arr} = ${sum}`);

// Objects in JavaScript
// const user = {
//     firstname: "John",
//     lastname: "Doe",
//     company: {
//         salary: 10000,
//         position: "Software Developer",
//     },
        // skills: ["HTML", "CSS", "JAVASCRIPT", "NODEJS", "EXPRESSJS", "MONGODB"];
// }
// const user2 = {} // empty object
// console.log(user);
// console.log(user.firstname);
// console.log(user['lastname']);

// user.age = 34; // add keys and values in object
// user['lastname'] = "Singh"; // we can update values in object
// delete user.firstname; // we can delete a key:value pair in object
// // console.log(user);
// console.log(Object.keys(user)); // display all keys
// console.log(Object.values(user)); // display all values
// console.log(Object.entries(user)); // display all key:value pairs


// Functions

// Function is a block of reusable code that we use so that we can follow rule called Do not Repeat Yourself(DRY) principle.

// function add(a, b){ // hoisted function
//     const c = a+b;
//     return c;
// }
// console.log(add(5, 6));

// const add = function(a, b){ // non-hoisted
//     const c = a+b;
//     return c;
// }

// const add = function addition(a, b) { // non-hoisted
//     const c = a+b;
//     return c;
// }

// Recursive function
// const fact = function factorial(num){
//     // return num<=1 ? 1 : num * factorial(num-1);
//     if(num<=1){
//         return 1;
//     }
//     else{
//         return num * factorial(num-1); // 5 * 4 * 3 * 2 * 1 * 1
//     }
// }
// console.log(fact(5));


// const arr = [12, 53, 23, 76, 56];
// function addArr(arr) {
//     const sum = arr.reduce((acc, num)=>acc+num);
//     return sum;
// }
// console.log(addArr(arr))


// const user = {
//     add: function(a, b){
//         return a+b;
//     }
// }


// const sum = (a, b) => {return a+b}; // arrow function
// const subs = (a, b) => { return a-b};
// console.log(sum(5, 7));
// console.log(subs(15, 2));

// function greet(name = "Guest"){
//     console.log(`Hello to you, ${name}`);
// }
// // greet("Carrie");
// greet();

// loops

// for loop
// for(let i=1; i<=10; i++){
//     console.log(`5 x ${i} = ${5*i}`);
// }
// let i = 1;

// while loop
// while (i<=10){
//     console.log(`5 x ${i} = ${5*i++}`);
// }

//do-while loop
// do{
//     console.log(`5 x ${i} = ${5 * i++}`);
// }while(i<=10)
// for(let i=0; i<=arr.length-1; i++){
//     console.log(arr[i]);
// }

// for-of loop
// const arr = [12, 54, 67, 44, 88, 24];


// for (const item of arr) {
//     console.log(item);
// }


// for-in loop
// const user = {
//     fname: "John",
//     lname: "Doe",
//     age: 45,
//     occupation: "Java Developer",
// }

// for(const key in user ){
//     console.log(`${key} : ${user[key]}`);
// }

// for-each
// const arr = [12, 54, 67, 44, 88, 24];

// arr.forEach(x=>console.log(x));









