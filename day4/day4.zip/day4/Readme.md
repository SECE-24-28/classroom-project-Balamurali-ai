# JavaScript
## What is Javascript
JavaScript is a client-side, dynamic programming language that we use in conjunction with outr HTML files in order to make it more interactive.

- Client-Side
- Dynamically typed - assign a value to a variable without mentioning its data type.
- Interpreted - reads code one line at a time.