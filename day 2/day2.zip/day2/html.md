# What is HTML?
- Hypertext - link one tex to another just like hyperlink.
- Mark-up - tags or annotations that we use to give to a set of text some meaning or structure.
- mark-up language - A set of rules that we need to follow in order to get the desired markup in our browsers or processors.
# Types of CSS
- Inline - use styles directly inside a html tag.
- internal - use usig style tag tag inside our htm;l file.
- external - create a separate file for styles and link it to the said html file.